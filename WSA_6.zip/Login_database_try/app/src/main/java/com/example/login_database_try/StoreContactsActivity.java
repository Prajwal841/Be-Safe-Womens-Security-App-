package com.example.login_database_try;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class StoreContactsActivity extends AppCompatActivity {
    EditText con1, con2, con3;
    Button ok;
    ArrayList<Integer> contactList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storecontacts);

        con1 = findViewById(R.id.contact_1);
        con2 = findViewById(R.id.contact_2);
        con3 = findViewById(R.id.contact_3);
        ok = findViewById(R.id.btn_goto_home);


        ok.setOnClickListener(view->{
            store();
        });
    }

//    private void storeToSQLite() {
//
//        if(con1.length()<10 || con1.length()>10)
//        {
//            con1.setError("Invalid Contact");
//            con1.requestFocus();
//        }
//        else if(con2.length()<10 || con2.length()>10)
//        {
//            con2.setError("Invalid Contact");
//            con2.requestFocus();
//        }
//        else if(con3.length()<10 || con3.length()>10)
//        {
//            con3.setError("Invalid Contact");
//            con3.requestFocus();
//        }
//        else if(con1.getText().toString()==con2.getText().toString())
//        {
//            con2.setError("Contact cannot be same");
//            con2.requestFocus();
//        }
//        else if(con1.getText().toString()==con3.getText().toString())
//        {
//            con3.setError("Contact cannot be same");
//            con3.requestFocus();
//        }
//        else if(con3.getText().toString()==con2.getText().toString())
//        {
//            con3.setError("Contact cannot be same");
//            con3.requestFocus();
//        }
//        else if(con1.getText().toString()==con2.getText().toString()
//                && con2.getText().toString()==con3.getText().toString())
//        {
//            con2.setError("Contact cannot be same");
//            con2.requestFocus();
//
//            con3.setError("Contact cannot be same");
//            con3.requestFocus();
//        }
//        else if(TextUtils.isEmpty(con1.getText()))
//        {
//            con1.setError("Contact required");
//            con1.requestFocus();
//        }
//        else if(TextUtils.isEmpty(con2.getText()))
//        {
//            con2.setError("Contact required");
//            con2.requestFocus();
//        }
//        else if(TextUtils.isEmpty(con3.getText()))
//        {
//            con3.setError("Contact required");
//            con3.requestFocus();
//        }
//        else
//        {
//            try {
//                int c1 = Integer.parseInt(con1.getText().toString());
//                int c2 = Integer.parseInt(con2.getText().toString());
//                int c3 = Integer.parseInt(con3.getText().toString());
//
//                Contact c = new Contact(c1, c2, c3);
//                DBHelper db = new DBHelper(StoreContactsActivity.this, "Contacts", null, 1);
//                db.addRecord(c);
//
//                Intent i = new Intent(StoreContactsActivity.this, MainActivity.class);
//                Log.d("Store", "Data stored successfully");
//                i.putExtra("Id", c1);
//                startActivity(i);
//
//            }catch (Exception e)
//            {
//                Log.e("Contact", "Error in getting data from edittext "+e);
//            }
//        }
//
//    }

    private void store() {
        if(con1.length()<10 || con1.length()>10)
        {
            con1.setError("Invalid Contact");
            con1.requestFocus();
        }
        else if(con2.length()<10 || con2.length()>10)
        {
            con2.setError("Invalid Contact");
            con2.requestFocus();
        }
        else if(con3.length()<10 || con3.length()>10)
        {
            con3.setError("Invalid Contact");
            con3.requestFocus();
        }
        else if(con1.getText().toString()==con2.getText().toString())
        {
            con2.setError("Contact cannot be same");
            con2.requestFocus();
        }
        else if(con1.getText().toString()==con3.getText().toString())
        {
            con3.setError("Contact cannot be same");
            con3.requestFocus();
        }
        else if(con3.getText().toString()==con2.getText().toString())
        {
            con3.setError("Contact cannot be same");
            con3.requestFocus();
        }
        else if(con1.getText().toString()==con2.getText().toString()
                && con2.getText().toString()==con3.getText().toString())
        {
            con2.setError("Contact cannot be same");
            con2.requestFocus();

            con3.setError("Contact cannot be same");
            con3.requestFocus();
        }
        else if(TextUtils.isEmpty(con1.getText()))
        {
            con1.setError("Contact required");
            con1.requestFocus();
        }
        else if(TextUtils.isEmpty(con2.getText()))
        {
            con2.setError("Contact required");
            con2.requestFocus();
        }
        else if(TextUtils.isEmpty(con3.getText()))
        {
            con3.setError("Contact required");
            con3.requestFocus();
        }
        else
        {
            try {
                int c1 = Integer.parseInt(con1.getText().toString());
                int c2 = Integer.parseInt(con2.getText().toString());
                int c3 = Integer.parseInt(con3.getText().toString());

                contactList.add(c1);
                contactList.add(c2);
                contactList.add(c3);
            }catch (Exception e)
            {
                Log.e("Contact", "Error in getting data from edittext "+e);
            }

            Intent i = new Intent(StoreContactsActivity.this, MainActivity.class);
            Log.d("Store", "Data stored successfully");
            i.putExtra("ContactList", contactList);
            i.putExtra("Id", contactList.get(0));
            startActivity(i);
        }

    }
}

