package com.example.login_database_try;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private String databaseName;
    private String tableName="Contacts";
    private String key_con1="Con1";
    private String key_con2="Con2";
    private String key_con3="Con3";


    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + tableName+ "("+ key_con1.toString()+" INTEGER PRIMARY KEY,"
                + key_con2+" INTEGER,"+ key_con3+" INTEGER,);";

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+tableName);
        onCreate(db);
    }

    void addRecord(Contact c)
    {
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(key_con1, c.getCon1());
            values.put(key_con2, c.getCon2());
            values.put(key_con3, c.getCon3());

            db.insert(tableName, null, values);
            db.close();
        }catch (Exception e)
        {
            e.printStackTrace();
            Log.e("test","Exception due to"+e.toString());
        }
    }

    Contact getRecord(int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(tableName, new String[]{key_con1, key_con2, key_con3},
                key_con1+" = ? ", new String[]{String.valueOf(id)},
                null, null, null, null);

        if(cursor != null)
        {
            cursor.moveToFirst();
        }

        Contact c = new Contact(Integer.parseInt(cursor.getString(0)),
                Integer.parseInt(cursor.getString(1)), Integer.parseInt(cursor.getString(2)));

        return c;
    }

}
