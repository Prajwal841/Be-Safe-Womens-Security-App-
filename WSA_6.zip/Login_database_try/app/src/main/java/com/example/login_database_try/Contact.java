package com.example.login_database_try;

import androidx.appcompat.app.AppCompatActivity;

public class Contact extends AppCompatActivity {
    int con1;
    int con2;
    int con3;

    public Contact() {
    }

    public Contact(int con1, int con2, int con3) {
        this.con1 = con1;
        this.con2 = con2;
        this.con3 = con3;
    }

    public int getCon1() {
        return con1;
    }

    public void setCon1(int con1) {
        this.con1 = con1;
    }

    public int getCon2() {
        return con2;
    }

    public void setCon2(int con2) {
        this.con2 = con2;
    }

    public int getCon3() {
        return con3;
    }

    public void setCon3(int con3) {
        this.con3 = con3;
    }
}
