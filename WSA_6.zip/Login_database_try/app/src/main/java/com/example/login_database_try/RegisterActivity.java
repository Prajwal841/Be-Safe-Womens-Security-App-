package com.example.login_database_try;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    FirebaseAuth mAuth;
    EditText edit_email;
    EditText edit_password;
    Button btn_login;
    Button btn_register;
    String pattern = "^[a-zA-Z0-9+_.-]+@[a-z]+\\.[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        edit_email = findViewById(R.id.edit_email);
        edit_password = findViewById(R.id.edit_password);
        btn_login = findViewById(R.id.btn_login);
        btn_register = findViewById(R.id.btn_register);

        mAuth = FirebaseAuth.getInstance();

        btn_register.setOnClickListener(view->{
            createUser();
        });

        btn_login.setOnClickListener(view->{
            Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(i);
        });
    }

    private void createUser()
    {
        String email = edit_email.getText().toString();
        String password = edit_password.getText().toString();

        if(email.isEmpty())
        {
            edit_email.setError("Email cannot be empty");
            edit_email.requestFocus();
        }
        else if(password.isEmpty())
        {
            edit_password.setError("Password cannot be empty");
            edit_password.requestFocus();
        }
        else if(!email.matches(pattern))
        {
            edit_email.setError("Invalid email");
            edit_email.requestFocus();
        }
        else if(password.length() < 8)
        {
            edit_password.setError("Password cannot be less than 8 characters");
            edit_password.requestFocus();
        }
        else
        {
            mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful())
                    {
                        Toast.makeText(RegisterActivity.this, "User registered successfully", Toast.LENGTH_SHORT).show();

                        Intent i_login = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(i_login);
                        RegisterActivity.this.finish();
                    }
                    else
                    {
                        Toast.makeText(RegisterActivity.this, "Registration error"+ task.getException(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}
