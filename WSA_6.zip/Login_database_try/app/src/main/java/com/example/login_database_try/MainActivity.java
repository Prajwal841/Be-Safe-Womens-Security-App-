package com.example.login_database_try;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    Button btn_logout;
    ImageButton sosButton;
    DBHelper db = new DBHelper(MainActivity.this, "Contacts", null, 1);

    ArrayList<Integer> contactList = new ArrayList<>();

    ImageButton imageButton2,imageButton6,imageButton7,imageButton5,imageButton77;

    private static int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        //SOS
        //id = getIntent().getExtras().getInt("Id");

        sosButton = (ImageButton) findViewById(R.id.sos_button);
        sosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMessages();
            }
        });

        //for scream
        imageButton2=findViewById(R.id.button3);
        MediaPlayer mediaPlayer = MediaPlayer.create(this,R.raw.help);

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.start();
            }
        });

        //for video
        imageButton7=(ImageButton) findViewById(R.id.button7);
        imageButton7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this, Play_video.class);
                startActivity(i);
            }
        });

        //for emergency button
        imageButton5=(ImageButton) findViewById(R.id.button5);
        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j=new Intent(MainActivity.this, Emergency.class);
                startActivity(j);
            }
        });



        //Safety tips
        imageButton6=(ImageButton) findViewById(R.id.button6);
        imageButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent nextactivity=new Intent(MainActivity.this,Safety_tips.class);
                    startActivity(nextactivity);
                }catch (Exception e)
                {
                    Log.e("Safety", "Error in launching activity");
                }
            }
        });

        //Logging out
        btn_logout = findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(view->{
            mAuth.signOut();
            Intent i = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(i);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();

        if(user==null)
        {
            Intent i_reg = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(i_reg);
        }
    }

    private void sendMessages() {
        try {

            contactList = (ArrayList<Integer>)getIntent().getSerializableExtra("ContactList");
            Log.d("smsIntent", "Get extra successful");

            for(int i=0; i<3; i++)
            {
                Log.i("Send SMS", "");
                Intent smsIntent = new Intent(Intent.ACTION_VIEW);

                smsIntent.setData(Uri.parse("smsto:"));
                smsIntent.setType("vnd.android-dir/mms-sms");
                smsIntent.putExtra("address"  , new String (contactList.get(i).toString()));
                smsIntent.putExtra("sms_body"  , "I'm in danger. Help!!");

                startActivity(smsIntent);
                finish();

                Log.i("SMS", "Sent message to contact "+i);
            }
        }
        catch (android.content.ActivityNotFoundException ex)
        {
            Log.e("SMS", "Sending sms failed");
            Toast.makeText(MainActivity.this,
                    "SMS failed, please try again later.", Toast.LENGTH_SHORT).show();
        }
    }

//    private void sendMessages() {
//        try {
//            //id = getIntent().getExtras().getInt("Id");
//            Contact c = db.getRecord(id);
//            int c1 = c.getCon1();
//            int c2 = c.getCon2();
//            int c3 = c.getCon3();
//
//            int arr[] = {c1, c2, c3};
//
//            for(int i=0; i<3; i++)
//            {
//                Log.i("Send SMS", "");
//                Intent smsIntent = new Intent(Intent.ACTION_VIEW);
//
//                smsIntent.setData(Uri.parse("smsto:"));
//                smsIntent.setType("vnd.android-dir/mms-sms");
//                smsIntent.putExtra("address"  , arr[i]);
//                smsIntent.putExtra("sms_body"  , "Help!!");
//
//                startActivity(smsIntent);
//                finish();
//
//                Log.i("SMS", "Sent message to contact "+i);
//            }
//        }
//        catch (android.content.ActivityNotFoundException ex)
//        {
//            Log.e("SMS", "Sending sms failed");
//            Toast.makeText(MainActivity.this,
//                    "SMS failed, please try again later.", Toast.LENGTH_SHORT).show();
//        }
//    }


}
